var searchData=
[
  ['querypalette',['QueryPalette',['../class_material_design_themes_1_1_wpf_1_1_palette_helper.html#ae89e33f6adb029dd8aaa5cd306aa9b1d',1,'MaterialDesignThemes::Wpf::PaletteHelper']]]
];
