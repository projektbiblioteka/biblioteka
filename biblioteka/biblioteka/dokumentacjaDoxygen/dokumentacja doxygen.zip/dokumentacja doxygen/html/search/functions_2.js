var searchData=
[
  ['delete_5fbtn_5fclick',['delete_btn_Click',['../classbiblioteka_1_1book__list.html#a505262aead9a7df5e90baffe27179880',1,'biblioteka::book_list']]]
];
