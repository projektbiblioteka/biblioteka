var searchData=
[
  ['replacepalette',['ReplacePalette',['../class_material_design_themes_1_1_wpf_1_1_palette_helper.html#a9174c715e9fdb71b43622f18ed0c3c5d',1,'MaterialDesignThemes::Wpf::PaletteHelper']]],
  ['replaceprimarycolor',['ReplacePrimaryColor',['../class_material_design_themes_1_1_wpf_1_1_palette_helper.html#a2b7946823aee93073d39572a5a2c48cf',1,'MaterialDesignThemes::Wpf::PaletteHelper']]]
];
