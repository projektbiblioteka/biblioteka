var searchData=
[
  ['bottomandaligncentres',['BottomAndAlignCentres',['../namespace_material_design_themes_1_1_wpf.html#aa5ff74ea870d218ca527b0313b4f89a7a3074a9fcab8ac0d41bdc1905fb67509b',1,'MaterialDesignThemes::Wpf']]],
  ['bottomandalignleftedges',['BottomAndAlignLeftEdges',['../namespace_material_design_themes_1_1_wpf.html#aa5ff74ea870d218ca527b0313b4f89a7a74ae26bd3433eee5bbb4fa8c68f697d2',1,'MaterialDesignThemes::Wpf']]],
  ['bottomandalignrightedges',['BottomAndAlignRightEdges',['../namespace_material_design_themes_1_1_wpf.html#aa5ff74ea870d218ca527b0313b4f89a7a4a0258bdb4a0c60876e9ecf41ab97ac1',1,'MaterialDesignThemes::Wpf']]]
];
