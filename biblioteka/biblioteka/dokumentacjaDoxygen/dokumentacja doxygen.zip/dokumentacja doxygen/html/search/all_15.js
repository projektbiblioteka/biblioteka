var searchData=
[
  ['xamlgeneratednamespace',['XamlGeneratedNamespace',['../namespace_xaml_generated_namespace.html',1,'']]]
];
