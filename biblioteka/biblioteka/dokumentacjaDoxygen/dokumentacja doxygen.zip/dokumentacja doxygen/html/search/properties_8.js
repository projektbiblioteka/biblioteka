var searchData=
[
  ['session',['Session',['../class_material_design_themes_1_1_wpf_1_1_dialog_closing_event_args.html#a3d0886d06b7992af71044ab13f015ec3',1,'MaterialDesignThemes.Wpf.DialogClosingEventArgs.Session()'],['../class_material_design_themes_1_1_wpf_1_1_dialog_opened_event_args.html#a31952c513e2ac7f49fa50dfcd9ed01a2',1,'MaterialDesignThemes.Wpf.DialogOpenedEventArgs.Session()']]],
  ['snackbarmessagequeue',['SnackbarMessageQueue',['../class_material_design_themes_1_1_wpf_1_1_dialog_host.html#a92540ba74b6040f15e9f2be8a228f1e3',1,'MaterialDesignThemes::Wpf::DialogHost']]],
  ['staysopen',['StaysOpen',['../class_material_design_themes_1_1_wpf_1_1_popup_box.html#a3d221754b314f30bfb002513f3096995',1,'MaterialDesignThemes::Wpf::PopupBox']]]
];
