var searchData=
[
  ['unfurlorientationproperty',['UnfurlOrientationProperty',['../class_material_design_themes_1_1_wpf_1_1_popup_box.html#a31e2abaaf069a945fc9b8320e935e1c6',1,'MaterialDesignThemes::Wpf::PopupBox']]]
];
