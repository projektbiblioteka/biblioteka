var searchData=
[
  ['main',['Main',['../classbiblioteka_1_1_app.html#ac8ced1ae80f0bd1ad74f9960088bae31',1,'biblioteka.App.Main()'],['../classbiblioteka_1_1_app.html#ac8ced1ae80f0bd1ad74f9960088bae31',1,'biblioteka.App.Main()']]]
];
