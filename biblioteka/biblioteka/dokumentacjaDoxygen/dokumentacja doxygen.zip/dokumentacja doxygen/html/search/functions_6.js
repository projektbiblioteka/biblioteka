var searchData=
[
  ['loadlastrownumber',['loadlastrownumber',['../classbiblioteka_1_1_dodawaniewypozyczenia.html#ac333a7dac19d160964d4585e3e8de46a',1,'biblioteka::Dodawaniewypozyczenia']]]
];
