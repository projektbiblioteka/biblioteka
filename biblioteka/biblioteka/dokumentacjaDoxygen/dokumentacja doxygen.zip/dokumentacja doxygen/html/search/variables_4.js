var searchData=
[
  ['opendialogcommand',['OpenDialogCommand',['../class_material_design_themes_1_1_wpf_1_1_dialog_host.html#ae0dfee337acd3cfcded52414cde83b13',1,'MaterialDesignThemes::Wpf::DialogHost']]]
];
