var searchData=
[
  ['popupplacementmethod',['PopupPlacementMethod',['../class_material_design_themes_1_1_wpf_1_1_popup_box.html#a699f201511033789f0f2ad847e879d8d',1,'MaterialDesignThemes::Wpf::PopupBox']]]
];
