var searchData=
[
  ['click',['Click',['../namespace_material_design_themes_1_1_wpf.html#ad51a6b0571cab3f9b83c1be65f78a0b9a316853cc3718335f11c048e33b9be98a',1,'MaterialDesignThemes::Wpf']]]
];
