var searchData=
[
  ['dialoghostinstance',['DialogHostInstance',['../namespace_material_design_themes_1_1_wpf.html#a5e8e71a774685efa8f51e32d9191ad02a62a654d98ccab22fd5262ca0262325b4',1,'MaterialDesignThemes::Wpf']]]
];
