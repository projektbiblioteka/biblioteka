var searchData=
[
  ['closedialogcommand',['CloseDialogCommand',['../class_material_design_themes_1_1_wpf_1_1_dialog_host.html#aabd583a620502cddc6258a5bc1fb8f06',1,'MaterialDesignThemes::Wpf::DialogHost']]],
  ['content',['Content',['../class_material_design_themes_1_1_wpf_1_1_dialog_closing_event_args.html#a4b12001b9375a6e91627dd62678b8ec0',1,'MaterialDesignThemes.Wpf.DialogClosingEventArgs.Content()'],['../class_material_design_themes_1_1_wpf_1_1_dialog_session.html#a571174167c468899ed59a06a9b0d4e30',1,'MaterialDesignThemes.Wpf.DialogSession.Content()']]]
];
