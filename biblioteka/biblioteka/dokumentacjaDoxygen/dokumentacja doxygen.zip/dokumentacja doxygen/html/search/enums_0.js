var searchData=
[
  ['dialoghostopendialogcommanddatacontextsource',['DialogHostOpenDialogCommandDataContextSource',['../namespace_material_design_themes_1_1_wpf.html#a5e8e71a774685efa8f51e32d9191ad02',1,'MaterialDesignThemes::Wpf']]]
];
